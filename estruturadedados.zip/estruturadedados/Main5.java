
// questao 8
import java.util.Scanner;

public class Main5 {
	public static void main(String[] args) {
		int n;
		Scanner input = new Scanner(System.in);
		do {
			n = input.nextInt();
			int[] v = new int[n];
			for (int i = 0; i < n; i++) {
				v[i] = input.nextInt();
			}
			int p = 1;
			do {
				p = input.nextInt();
				remove(v, p);
			} while (p != 0);
		} while (n != 0);
	}

	private static int[] remove(int[] set, int p) {
		for (int i = 0; i < set.length; i++) {
			if (set[i] == p) {
				ArrayUtils.removeElement(set, p);
			}
		}
		return set;
	}
}
