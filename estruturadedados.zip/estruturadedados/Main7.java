package estruturadedados;

import java.util.Scanner;

/**
 * Main7
 */
public class Main7 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n, r = 0, resultado = 0, aux = 0;
		do {
			n = input.nextInt();
			for (int i = 1; i <= n; i++) {
				r = input.nextInt();
				if (r == i) {
					resultado = r;
				}
			}
			System.out.println("Teste " + aux);
			System.out.println(resultado);
			aux++;
		} while (n != 0);
	}
}
