package estruturadedados;

/**
 * Main6
 */
public class Main6 {

	public static boolean buscar(int[] set, int n, int i) {
		while (i > 0) {
			if (set[i - 1] == n) {
				return true;
			}
			buscar(set, n, i - 1);
		}
		return false;
	}

	public static void main(String[] args) {
		int[] set = { 1, 2, 3, 4, 5 };
		boolean b = buscar(set, 4, set.length);
		System.out.println(b);
	}
}
