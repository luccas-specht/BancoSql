package estruturadedados;

/**
 * Funcionario
 */
public class Funcionario {
	private String nome;
	private String cargo;
	private int salario;

	public Funcionario(String nome, String cargo, int salario) {
		this.nome = nome;
		this.cargo = cargo;
		this.salario = salario;
	}

	/**
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
	 * @param cargo the cargo to set
	 */
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	/**
	 * @param salario the salario to set
	 */
	public void setSalario(int salario) {
		this.salario = salario;
	}

	/**
	 * @return the nome
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * @return the cargo
	 */
	public String getCargo() {
		return cargo;
	}

	/**
	 * @return the salario
	 */
	public int getSalario() {
		return salario;
	}
}
