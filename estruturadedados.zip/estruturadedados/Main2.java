package estruturadedados;

/**
 * Exercício 5
 */
public class Main2 {
	public static void main(String[] args) {
		Funcionario[] v1 = lerDados();

	}

	public static Funcionario[] mergeSort(Funcionario[] f) {

	}

	public static Funcionario[] lerDados() {
		Funcionario[] v = new Funcionario[7];
		v[0] = new Funcionario("Joaquim", "PHP", 3730);
		v[1] = new Funcionario("Ana", "Java", 3125);
		v[2] = new Funcionario("Joaquim", "PHP", 3530);
		v[3] = new Funcionario("Joana", "Cobol", 25313);
		v[4] = new Funcionario("Ana", "Java", 2350);
		v[5] = new Funcionario("Tesla", "Haskell", 9234);
		v[6] = new Funcionario("Fernanda", "Javascript", 2760);
		return v;
	}

}
