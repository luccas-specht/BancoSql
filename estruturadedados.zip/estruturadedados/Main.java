package estruturadedados;

public class Main {
	public static void main(String[] args) {
		int[] v1 = { 4, 3, 96, 8, 4, 5, 1, 17 };
		int[] v2 = { 17, 3, 34, 8, 4, 127, 8 };
		int[] aux = new int[10];
		int temp = 0;

		for (int i = 0; i < v1.length; i++) {
			if (possui(v1, v1[i]) && possui(v2, v1[i]) && !possui(aux, v1[i])) {
				aux[temp] = v1[i];
				temp++;
			}
		}

		int[] uni = uniao(v1, v2);
		bubbleSort(uni);
		bubbleSort(aux);

		// for (int x : aux) {
		// System.out.println(x);
		// }

		for (int x : uni) {
			System.out.println(x);
		}
	}

	private static void bubbleSort(int[] v) {
		boolean troca = true;
		int aux;
		while (troca) {
			troca = false;
			for (int i = 0; i < v.length - 1; i++) {
				if (v[i] > v[i + 1]) {
					aux = v[i];
					v[i] = v[i + 1];
					v[i + 1] = aux;
					troca = true;
				}
			}
		}
	}

	public static boolean possui(int[] v, int target) {
		for (int i : v) {
			if (i == target) {
				return true;
			}
		}
		return false;
	}

	public static int[] uniao(int[] v1, int[] v2) {
		int[] retorno = new int[v1.length + v2.length];
		int aux = 0;
		for (int i = 0; i < v1.length; i++) {
			retorno[aux] = v1[i];
			aux++;
		}
		for (int i = 0; i < v2.length; i++) {
			retorno[aux] = v2[i];
			aux++;
		}
		return retorno;
	}
}
