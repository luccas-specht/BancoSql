package estruturadedados;

/**
 * Exercício 3
 */
public class Main1 {
	public static void main(String[] args) {
		int n = 4;
		int[] v = { 4, 3, 108, 8, 4, 5, 1, 17, 20 };
		int[] aux = new int[10];
		int temp = 0;
		for (int i = 0; i < v.length; i++) {
			if (v[i] % n == 0) {
				aux[temp] = v[i];
				temp++;
			}
		}
	}
}
