public class Main3 {
	public static void main(String[] args) {
		int[][] matriz = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
		getTranspose(matriz);
		rotateAlongDiagonal(matriz);
	}

	private static void rotateAlongDiagonal(int[][] matrix) {
		int len = matrix.length;
		for (int i = 0; i < len; i++) {
			for (int j = 0; j < len - 1 - i; j++) {
				int temp = matrix[i][j];
				matrix[i][j] = matrix[len - 1 - j][len - 1 - i];
				matrix[len - 1 - j][len - 1 - i] = temp;
			}
		}
	}

	private static void getTranspose(int[][] matrix) {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = i + 1; j < matrix.length; j++) {
				int temp = matrix[i][j];
				matrix[i][j] = matrix[j][i];
				matrix[j][i] = temp;
			}
		}
	}
}
